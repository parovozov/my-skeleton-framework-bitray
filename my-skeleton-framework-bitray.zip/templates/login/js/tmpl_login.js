<?php
echo "privet eto templates";
?>