<?php
$ctrl=new defaultControl();
?>
<!DOCTYPE html>
<html lang="ru-ru">
<head>
<?php
echo $ctrl->getMetaDescription();
echo $ctrl->getMetaKeyWords();
echo $ctrl->getMetatitle();
?>
