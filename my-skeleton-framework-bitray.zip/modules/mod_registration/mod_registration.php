<div class="reg_modele_dib">
<?php 
echo "тут модуль регистрации";
?>
</div>